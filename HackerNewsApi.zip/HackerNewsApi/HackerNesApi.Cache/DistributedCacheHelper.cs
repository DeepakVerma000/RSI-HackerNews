﻿using Microsoft.Extensions.Caching.Distributed;
using System;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace HackerNewsApi.Cache
{
    public class DistributedCacheHelper : IDistributedCacheHelper
    {
        private IDistributedCache _redisCache;
        private DistributedCacheEntryOptions _cacheOptions;
        public DistributedCacheHelper(IDistributedCache cache)
        {
            _redisCache = cache;
            _cacheOptions = new DistributedCacheEntryOptions().SetAbsoluteExpiration(DateTime.UtcNow.AddHours(23));
        }

        public async Task<dynamic> GetFromCache<TResult>(string cachedKey)
        {
            var dataFromRedis = await _redisCache.GetAsync(cachedKey);
            if ((dataFromRedis?.Count() ?? 0) > 0)
            {
                var dataToString = Encoding.UTF8.GetString(dataFromRedis);
                return JsonSerializer.Deserialize<TResult>(dataToString);
            }
            return null;
        }
        public async Task SetIntoCache(dynamic responseData, string cachedKey)
        {
            var cachedDataString = JsonSerializer.Serialize(responseData);
            var dataToCache = Encoding.UTF8.GetBytes(cachedDataString);
            if (_cacheOptions.AbsoluteExpiration.HasValue && _cacheOptions.AbsoluteExpiration.Value <= DateTime.UtcNow)
            {
                _cacheOptions.SetAbsoluteExpiration(DateTime.UtcNow.AddHours(23));
                await _redisCache.RefreshAsync(cachedKey);
            }
            await _redisCache.SetAsync(cachedKey, dataToCache, _cacheOptions);
        }

        public async Task RemoveCache(string cachekey)
        {
            await _redisCache.RemoveAsync(cachekey);
        }
    }
}
