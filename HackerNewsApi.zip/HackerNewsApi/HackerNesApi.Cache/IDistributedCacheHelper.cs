﻿using System.Threading.Tasks;

namespace HackerNewsApi.Cache
{
    public interface IDistributedCacheHelper
    {
        Task<dynamic> GetFromCache<TResult>(string cachedKey);
        Task SetIntoCache(dynamic responseData, string cachedKey);
        Task RemoveCache(string cachekey);
    }
}
