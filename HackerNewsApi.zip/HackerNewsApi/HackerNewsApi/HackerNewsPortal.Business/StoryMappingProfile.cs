﻿using HackerNewsApi.HackerNewsPortal.Business.Models;
using AutoMapper;
using HackerNewsApi.HackerNewsPortal.Entity;

namespace HackerNewsApi.HackerNewsPortal.Business
{
    public class StoryMappingProfile : Profile
    {
        public StoryMappingProfile()
        {
            CreateMap<Story, StoryReadModel>()
             .ForMember(dest => dest.IsDeleted, opt => opt.MapFrom(src => src.Deleted))
             .ForMember(dest => dest.IsExpired, opt => opt.MapFrom(src => src.Dead))
             .ForMember(dest => dest.User, opt => opt.MapFrom(src => src.By))
             .ForMember(dest => dest.TotalCommentCount, opt => opt.MapFrom(src => src.Descendants))
             .ForMember(dest => dest.Time, opt => opt.MapFrom(src => src.Time));
        }
    }
}

