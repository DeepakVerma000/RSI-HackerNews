﻿namespace HackerNewsApi.HackerNewsPortal.Business.Manager
{
    using AutoMapper;
    using global::HackerNewsApi.HackerNewsPortal.Entity;
    using HackerNewsApi.Extensions;
    using HackerNewsApi.HackerNewsPortal.Business.Models;
    using HackerNewsApi.HackerNewsPortal.Constant;
    using HackerNewsApi.HackerNewsPortal.DataAccess.Repository;
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Text.Json;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="StoryQueryManager" />.
    /// </summary>
    public class StoryManager : IStoryManager, IDisposable
    {

        /// <summary>
        /// Defines the _storyRepository.
        /// </summary>
        private readonly IStoryRepository _storyRepository;

        /// <summary>
        /// Defines the _mapper.
        /// </summary>
        private readonly IMapper _mapper;
        public StoryManager(IStoryRepository storyRepository, IMapper mapper)
        {
            _storyRepository = storyRepository;
            _mapper = mapper;
        }

        /// <summary>
        /// GetAllStory method.
        /// </summary>
        /// <returns>
        /// List<StoryReadModel>.
        /// </returns>
        public async Task<List<StoryReadModel>> GetAllStory()
        {
            List<string> topStoriesIds;
           
            using (WebClient webClient = new WebClient())
            {
                var jsonStory = webClient.DownloadString(ApiConstants.ApiBaseUrl + "topstories.json?print=pretty");

                char[] separators = new char[] { '[', ']', '\n' };
                jsonStory = jsonStory.Replace(separators, "");
                topStoriesIds = jsonStory.Split(',').ToList();
            }

            IEnumerable<Story> lstStories = GetTopStoryById(topStoriesIds.Take(200).ToList());
            var records = _mapper.Map<List<StoryReadModel>>(lstStories);
            return records;
        }


        /// <summary>
        /// GetTopStoryById method.
        /// </summary>
        /// <param name="topStoriesIds">topStoriesIds.</param>
        /// <returns>
        /// List<Story>.
        /// </returns>
        public List<Story> GetTopStoryById(List<string> topStoriesIds)
        {
            List<Story> lstStoryDetails = new List<Story>();
            foreach (var storyId in topStoriesIds)
            {
                using (WebClient webClient = new WebClient())
                {
                    var url = ApiConstants.ApiBaseUrl+"item/" + storyId.Trim() + ".json?print=pretty";
                    var jsonStoryById = webClient.DownloadString(url);
                    Story story = JsonConvert.DeserializeObject<Story>(jsonStoryById);


                    if(!string.IsNullOrEmpty(story.Url) && story.Type.Equals("story"))
                        {
                        lstStoryDetails.Add(story);
                    }
                }
            }
            return lstStoryDetails.OrderByDescending(x => x.Id).ToList();
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _storyRepository.Dispose();
                }

                disposedValue = true;
            }
        }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion

       

    }

}
