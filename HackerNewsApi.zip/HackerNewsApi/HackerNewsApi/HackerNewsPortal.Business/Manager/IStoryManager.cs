﻿using HackerNewsApi.HackerNewsPortal.Business.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HackerNewsApi.HackerNewsPortal.Business.Manager
{

    /// <summary>
    /// Defines the <see cref="IStoryManager" />.
    /// </summary>
    public interface IStoryManager
    {
        /// <summary>
        /// GetallStories.
        /// </summary>
        /// <returns>List of story</returns>
        Task<List<StoryReadModel>> GetAllStory();
    }
}
