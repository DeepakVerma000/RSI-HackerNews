﻿namespace HackerNewsApi.HackerNewsPortal.Business.Models
{
    using System;

    /// <summary>
    /// Defines the <see cref="StoryReadModel" />.
    /// </summary>
    public class StoryReadModel
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StoryReadModel"/> class.
        /// </summary>
        public StoryReadModel()
        {
        }
        public int Id { get; set; }
        public long Time { get; set; }
        public string User { get; set; }
        public long TypeId { get; set; }
        public string Text { get; set; }
        public string Parent { get; set; }
        public string Poll { get; set; }
        public string[] Kids { get; set; }
        public string Url { get; set; }
        public int Score { get; set; }
        public string Title { get; set; }
        public string Parts { get; set; }
        public int TotalCommentCount { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsExpired { get; set; }
        public string Type { get; set; }
    }
}