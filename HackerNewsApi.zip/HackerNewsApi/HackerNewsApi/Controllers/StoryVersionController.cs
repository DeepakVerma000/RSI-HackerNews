﻿namespace HackerNewsApi.Controllers
{
    using HackerNewsApi.Cache;
    using HackerNewsApi.HackerNewsPortal.Business.Manager;
    using HackerNewsApi.HackerNewsPortal.Business.Models;
    using HackerNewsApi.HackerNewsPortal.Constant;
    using Microsoft.AspNetCore.Mvc;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    /// <summary>
    /// Defines the <see cref="StoryController" />.
    /// </summary>
    [ApiController]
    [Produces("application/json")]
    [Route("api/v2/[controller]")]
    public class StoryVersionController : ControllerBase
    {
        /// <summary>
        /// Defines the _manager.
        /// </summary>
        private readonly IStoryManager _manager;

        /// <summary>
        /// Defines the _redisCache.
        /// </summary>

        private IDistributedCacheHelper _redisCache;


        /// <summary>
        /// Initializes a new instance of the <see cref="StoryController"/> class.
        /// </summary>
        /// <param name="manager">The manager<see cref="StoryManager"/>.</param>
        /// <param name="redisCache">The cache<see cref="StoryManager"/>.</param>
        public StoryVersionController(IStoryManager manager, IDistributedCacheHelper redisCache)
        {
            _manager = manager;
            _redisCache = redisCache;
        }


        /// <summary>
        /// Get all stories details.
        /// </summary>
        /// <returns>
        /// <see cref="ManagerResponse{}"/> representing the result of the operation.
        /// </returns>

        [HttpGet]
        [Route("getAllStory")]
        public async Task<IActionResult> GetAllStory()
        {
            IEnumerable<StoryReadModel> result = await _redisCache.GetFromCache<IEnumerable<StoryReadModel>>($"{ApiConstants.CacheKey}");
            if (result == null)
            {
                result = await _manager.GetAllStory().ConfigureAwait(false);
                await _redisCache.SetIntoCache(result, $"{ApiConstants.CacheKey}");
            }
            return Ok(result);
        }
    }
}
