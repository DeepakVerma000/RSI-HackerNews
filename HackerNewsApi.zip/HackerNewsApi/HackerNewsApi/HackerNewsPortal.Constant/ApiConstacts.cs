﻿
namespace HackerNewsApi.HackerNewsPortal.Constant
{
    /// <summary>
    /// Defines the <see cref="ApiConstants" />.
    /// </summary>
    public static class ApiConstants
    {
        /// <summary>
        /// Defines the ApiName.
        /// </summary>
        public const string ApiName = "HackerNewsPortal API";

        /// <summary>
        /// Defines the ApiVersion.
        /// </summary>
        public const string ApiVersion = "v1";

        /// <summary>
        /// Defines the ApiBaseUrl.
        /// </summary>
        public const string ApiBaseUrl = "https://hacker-news.firebaseio.com/v0/";

        /// <summary>
        /// Defines the Cache Key Name.
        /// </summary>
        public const string CacheKey = "StoryKey";
    }
}
