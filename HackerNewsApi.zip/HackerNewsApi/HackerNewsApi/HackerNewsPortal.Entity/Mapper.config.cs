﻿using AutoMapper;
using HackerNewsApi.HackerNewsPortal.Entity;
using HackerNewsApi.HackerNewsPortal.Business.Models;

namespace HackerNewsApi.HackerNewsPortal.Configurations
{
    public class MapperConfig : Profile
    {
        public MapperConfig()
        {
            CreateMap<Story, StoryReadModel>().ReverseMap();
        }
    }
}
