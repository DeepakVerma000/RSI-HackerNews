using AutoMapper;
using HackerNewsApi.Cache;
using HackerNewsApi.HackerNewsPortal.Business;
using HackerNewsApi.HackerNewsPortal.Business.Manager;
using HackerNewsApi.HackerNewsPortal.Constant;
using HackerNewsApi.HackerNewsPortal.DataAccess;
using HackerNewsApi.HackerNewsPortal.DataAccess.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;

namespace HackerNewsApi
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var connectionString = Configuration.GetConnectionString("DefaultDatabase");
            int defaultDBTimeOut = Configuration.GetValue<int>("DefaultDatabaseTimeout");
            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultDatabase")));
            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "HackerNewsApi", Version = "v1" });
            });
            services.AddTransient<IStoryManager, StoryManager>();
            services.AddTransient<IStoryRepository, StoryRepository>();
            services.AddTransient<IDistributedCacheHelper, DistributedCacheHelper>();
            var mapperConfig = new MapperConfiguration(mc => { mc.AddProfile(new StoryMappingProfile()); });
            services.AddApiVersioning(x =>
            {
                x.DefaultApiVersion = new ApiVersion(1, 0);
                x.AssumeDefaultVersionWhenUnspecified = true;
                x.ReportApiVersions = true;
                x.ApiVersionReader = new HeaderApiVersionReader("x-api-version");
            });
            services.AddDistributedMemoryCache();
            IMapper mapper = mapperConfig.CreateMapper(); services.AddSingleton(mapper);
            services.AddCors(options =>
            {
                options.AddPolicy("AllowAngularOrigins",
                builder =>
                {
                    builder.WithOrigins(
                                        "http://localhost:4200"
                                        )
                                        .AllowAnyHeader()
                                        .AllowAnyMethod();
                });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", ApiConstants.ApiName +" "+ ApiConstants.ApiVersion));
            }

            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthorization();
            app.UseCors("AllowAngularOrigins");
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
