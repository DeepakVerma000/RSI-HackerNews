﻿using HackerNewsApi.HackerNewsPortal.Entity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace HackerNewsApi.HackerNewsPortal.DataAccess
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext()
        {
        }
        public DbSet<Story> Stories { get; set; }
        public DbSet<NewsType> NewsTypes { get; set; }
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Story>()
                .HasOne(s => s.NewsType)
                .WithMany(c => c.Story)
                .HasForeignKey(s => s.TypeId);
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                IConfigurationRoot configuration = new ConfigurationBuilder()
                   .SetBasePath(Directory.GetCurrentDirectory())
                   .AddJsonFile("appsettings.Development.json")
                   .Build();
                var connectionString = configuration["ConnectionString:DefaultDatabase"];
                optionsBuilder.UseSqlServer(connectionString);
            }
        }
    }
}
