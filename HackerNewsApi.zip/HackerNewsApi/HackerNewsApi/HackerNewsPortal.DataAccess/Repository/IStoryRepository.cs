﻿using HackerNewsApi.HackerNewsPortal.Entity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HackerNewsApi.HackerNewsPortal.DataAccess.Repository
{
    public interface IStoryRepository : IDisposable
    {
        Task<IEnumerable<Story>> GetAllAsync();
    }
}
