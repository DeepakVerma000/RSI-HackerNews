﻿using HackerNewsApi.HackerNewsPortal.Entity;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HackerNewsApi.HackerNewsPortal.DataAccess.Repository
{
    public class StoryRepository : IStoryRepository, IDisposable
    {
        /// <summary>
        /// Defines the _context.
        /// </summary>
        private ApplicationDbContext _context;
        public StoryRepository()
        {
            _context = new ApplicationDbContext();
        }
        public async Task<IEnumerable<Story>> GetAllAsync()
        {
            return await this._context.Stories.Where(x => x.Deleted == false && x.Dead == false && x.Url != "").OrderByDescending(x => x.Id).AsNoTracking().ToListAsync();
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {

                    _context.Dispose();
                }

                disposedValue = true;
            }
        }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #endregion
    }
}

