using HackerNewsApi.Cache;
using HackerNewsApi.Controllers;
using HackerNewsApi.HackerNewsPortal.Business.Manager;
using HackerNewsApi.HackerNewsPortal.Business.Models;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;

namespace HackerNewsApi.Test
{
    public class Tests
    {
        private StoryController controller;
        private Mock<IStoryManager> storyManagerMock;
        private List<StoryReadModel> items;
        private Mock<IDistributedCacheHelper> _redisCache;

        [SetUp]
        public void Setup()
        {
            // arrange
            storyManagerMock = new Mock<IStoryManager>();
            _redisCache = new Mock<IDistributedCacheHelper>();
            controller = new StoryController(storyManagerMock.Object, _redisCache.Object);
            items = new List<StoryReadModel>();
            items.Add(new() { TypeId = 1, User = "dhouston", Time = 3534523452345, Text = "Text", Parent = "Parent", Poll = "Poll", 
                Kids = new string[]
                {
                    "8952, 9224, 8917, 8884, 8887, 8943, 8869, 8958, 9005, 9671, 8940, 9067, 8908, 9055, 8865, 8881, 8872, 8873, 8955, 10403, 8903, 8928, 9125, 8998, 8901, 8902, 8907, 8894, 8878, 8870, 8980, 8934, 8876"
                },
                Url = "http://www.getdropbox.com/u/2/screencast.html", Score = 111, Title = "My YC app: Dropbox - Throw away your USB drive story1", Parts = "parts", TotalCommentCount = 71, IsDeleted = false, IsExpired = false });

        }

        [Test]
        public void GetAllStoriesTest_Check_not_null()
        {
            // Arrange
            storyManagerMock.Setup(p => p.GetAllStory()).ReturnsAsync(items);
            controller = new StoryController(storyManagerMock.Object, _redisCache.Object);

            // Act
            var result = controller.GetAllStory().Result;

            // Assert
            Assert.NotNull(result);

        }
    }
}